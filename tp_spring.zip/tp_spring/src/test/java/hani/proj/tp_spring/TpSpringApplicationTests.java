package hani.proj.tp_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
