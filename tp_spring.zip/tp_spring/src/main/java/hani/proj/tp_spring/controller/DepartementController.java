package hani.proj.tp_spring.controller;

import hani.proj.tp_spring.entity.Departement;
import hani.proj.tp_spring.services.IDepartementServices;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/deps")
public class DepartementController {


    IDepartementServices departementServices;


    @GetMapping("/getDepartement/{idDepart}")
    public Departement getDepartements(@PathVariable Integer idDepart){return departementServices.getDepartementById(idDepart);}

    @GetMapping("/getAllDepartment")
    public List<Departement> getDepartementList(){return departementServices.getAllDepartements();}

    @PostMapping("/addDepartement")
    public Departement addDepartement(@RequestBody Departement d){return departementServices.addDepartement(d);}

    @PutMapping("/updateDepartement")
    public Departement updateDepartement(@RequestBody Departement d){return departementServices.updateDepartement(d);}

    @DeleteMapping("deleteDepartement/{idDepart}")
    public void deleteDepartement(@PathVariable Integer idDepart){departementServices.deleteDepartement(idDepart);}
}
