package hani.proj.tp_spring.services;

import hani.proj.tp_spring.entity.Equipe;


import java.util.List;

public interface IEquipeServices {
    List<Equipe> getAllEquipes();

    Equipe getEquipe (Integer idEquipe);

    Equipe addEquipe(Equipe e); // ajouter l’équipe avec son détail

    Equipe updateEquipe (Equipe e);

    void deleteEquipe (Integer idEquipe);

public Equipe hany (Equipe e);
}
