package hani.proj.tp_spring.services;

import hani.proj.tp_spring.entity.Contrat;
import hani.proj.tp_spring.entity.Etudiant;
import hani.proj.tp_spring.repository.ContratRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;


import java.util.Date;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

@Service
@AllArgsConstructor
public class ContratServiceImp implements  hani.proj.tp_spring.services.IContratServices {


    ContratRepository contratRepository;
    @Override
    public List<Contrat> getALLContrat() {
        return contratRepository.findAll();
    }

    @Override
    public Contrat addContrat(Contrat c) {
        return contratRepository.save(c);
    }

    @Override
    public Contrat updateContrat(Contrat c) {
        return contratRepository.save(c);
    }

    @Override
    public void deleteContrat(Integer id) {
        contratRepository.deleteById(id);

    }

    @Override
    public Contrat getContratById(Integer id) {
        return contratRepository.findById(id).orElse(null);
    }

    @Override
    //@Scheduled(cron = "0 0 13 */15 * *")
    @Scheduled(cron = "*/10 * * * * *")
    public String contratdatefin() {
      /*  DateTimeFormatter newform = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        ZoneId defaultZoneId=ZoneId.systemDefault();
        LocalDate datebefor=LocalDate.now().plusDays(15);
        System.out.println(datebefor);
       datebefor.format(newform);
       System.out.println(datebefor);*/

/*        List<Contrat> contrats=new ArrayList<>();
        contratRepository.getByDateFinContratBefore(datebefor).forEach(contrats::add);*/
        Date dt = new Date();
        Calendar ct = Calendar.getInstance();
        ct.setTime(dt);
        ct.add(Calendar.DATE, 15);
        dt = ct.getTime();
        List<Contrat> contrats = contratRepository.getByDateFinContratBefore(dt);
        for (Contrat c:contrats){
System.out.println("il rest 15 jour pour le fin de contrat");
        }
        return "fin";
    }


}
