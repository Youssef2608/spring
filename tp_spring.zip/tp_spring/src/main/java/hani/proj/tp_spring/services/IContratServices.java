package hani.proj.tp_spring.services;

import hani.proj.tp_spring.entity.Contrat;


import java.sql.Date;
import java.util.List;
import java.util.Set;

public interface IContratServices {
    List<Contrat> getALLContrat();
    Contrat addContrat(Contrat c);
    Contrat updateContrat(Contrat c);
    void deleteContrat(Integer id);
    Contrat getContratById(Integer id);
    String  contratdatefin ();
}
