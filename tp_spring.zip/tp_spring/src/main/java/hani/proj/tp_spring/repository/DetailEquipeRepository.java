package hani.proj.tp_spring.repository;

import hani.proj.tp_spring.entity.DetailEquipe;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.List;

public interface DetailEquipeRepository extends JpaRepository<DetailEquipe,Integer> {


}
