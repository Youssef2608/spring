package hani.proj.tp_spring.services;

import hani.proj.tp_spring.entity.Etudiant;
import hani.proj.tp_spring.repository.EtudiantRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
@AllArgsConstructor
@Service
public class EtudiantServiceImp implements  hani.proj.tp_spring.services.IEtudiantServices {


    EtudiantRepository etudiantRepository;

    @Override
    public List<Etudiant> getALLEtudiant() {
        return etudiantRepository.findAll();
    }

    @Override
    public Etudiant addEtudiant(Etudiant e) {
        return etudiantRepository.save(e);
    }

    @Override
    public Etudiant updateEtudiant(Etudiant e) {
        return etudiantRepository.save(e);
    }

    @Override
    public void deleteETudiant(Long id) {
        etudiantRepository.deleteById(id);
        System.out.println("deleted successfuly");

    }

    @Override
    public Etudiant getEtudiantById(Long id) {
        return etudiantRepository.findById(id).orElse(null);
    }

    @Override
    public Etudiant getEtudiantbyPrenomEtudiant(String prenom) {
        return etudiantRepository.findEtudiantByPrenomE(prenom);
    }



}
