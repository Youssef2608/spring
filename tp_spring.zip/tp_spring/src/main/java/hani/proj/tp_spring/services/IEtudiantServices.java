package hani.proj.tp_spring.services;


import hani.proj.tp_spring.entity.Etudiant;


import java.util.List;

public interface IEtudiantServices {
    List<Etudiant> getALLEtudiant();
    Etudiant addEtudiant(Etudiant e);
    Etudiant updateEtudiant(Etudiant e);
    void deleteETudiant(Long id);
    Etudiant getEtudiantById(Long id);

    Etudiant getEtudiantbyPrenomEtudiant(String prenom);

   // List<Equipe> findByEtudiantIdEtudiantAndDetailEquipeThematiqueNotNull (Integer idEtudiant);

    //List<Equipe> findByEtudiantIdEtudiantAndEtudiantDepartementIdDepart (Integer idEtudiant, Integer idDepart);


}
