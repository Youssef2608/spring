package hani.proj.tp_spring.entity;

public enum Option {
    GAMIX,SIM,SE,NIDS
}
