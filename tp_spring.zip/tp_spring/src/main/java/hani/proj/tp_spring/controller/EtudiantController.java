package hani.proj.tp_spring.controller;

import hani.proj.tp_spring.entity.Etudiant;
import hani.proj.tp_spring.services.IEtudiantServices;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/etudiant")
public class EtudiantController {

    IEtudiantServices etudiantServices;

    @GetMapping("/getAllEtudiant")
    public List<Etudiant> getAllEtudiant() {
        return etudiantServices.getALLEtudiant();
    }

    @PostMapping("/addEtudiant")
    public Etudiant addEtudiant(@RequestBody Etudiant e) {
        return etudiantServices.addEtudiant(e);
    }

    @PutMapping("/updateEtudiant")
    public Etudiant updatEtudiant(@RequestBody Etudiant e) {
        return etudiantServices.updateEtudiant(e);
    }

    @DeleteMapping("/deleteEtudiant/{idEtudiant}")
    void deleteETudiant(@PathVariable Long idEtudiant) {
        etudiantServices.deleteETudiant(idEtudiant);
    }

    @GetMapping("getEtudiant/{idEtudiant}")
    public Etudiant getEtudiant(@PathVariable Long idEtudiant) {
        return etudiantServices.getEtudiantById(idEtudiant);
    }

    @GetMapping("getEtudiantByPrenom/{PrenomEtudiant}")
    public Etudiant getEtudiantbyPrenomEtudiant(@PathVariable String PrenomEtudiant) {
        return etudiantServices.getEtudiantbyPrenomEtudiant(PrenomEtudiant);
    }
   /* @GetMapping("find")
    public List<Equipe> findByEtudiantIdEtudiantAndDetailEquipeThematiqueNotNull (Integer idEtudiant){return etudiantServices.findByEtudiantIdEtudiantAndDetailEquipeThematiqueNotNull(idEtudiant);}

    @GetMapping("findbydepart")
    public List<Equipe> findByEtudiantIdEtudiantAndEtudiantDepartementIdDepart (Integer idEtudiant, Integer idDepart){
        return etudiantServices.findByEtudiantIdEtudiantAndEtudiantDepartementIdDepart(idEtudiant,idDepart);
    }*/
}
