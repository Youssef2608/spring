package hani.proj.tp_spring.repository;

import hani.proj.tp_spring.entity.Departement;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DepartementRepository extends JpaRepository<Departement,Integer> {
}
