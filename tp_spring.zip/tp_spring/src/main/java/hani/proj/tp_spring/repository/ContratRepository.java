package hani.proj.tp_spring.repository;

import hani.proj.tp_spring.entity.Contrat;
import hani.proj.tp_spring.entity.Etudiant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;


public interface ContratRepository extends JpaRepository<Contrat,Integer> {
    Integer countByArchiveIsFalseAndEtudiant(Etudiant e );

    @Override
    Contrat getReferenceById(Integer integer);
    List<Contrat> getByDateFinContratBefore(Date d);
}
