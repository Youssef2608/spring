package hani.proj.tp_spring.controller;

import hani.proj.tp_spring.entity.Universite;
import hani.proj.tp_spring.services.IUniversiteServices;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@AllArgsConstructor
public class UniversiteController {

    IUniversiteServices universiteServices;

    @GetMapping("/getAllUniversite")
    public List<Universite> getAllUniverite(){
        return universiteServices.getAllUniversites();
    }

    @PostMapping("/addUniversite")
    public Universite addUniversite(@RequestBody Universite u){
        return universiteServices.addUniversite(u);
    }

    @PutMapping("/updateUniversite")
    public Universite updatUniversite(@RequestBody Universite u){
        return universiteServices.updateUniversite(u);
    }

    @DeleteMapping("/deleteUniversite/{idUniversite}")
    void deleteUniversite(@PathVariable Integer idUniversite){
        universiteServices.deleteUniversite(idUniversite);
    }

    @GetMapping("/getUniversite/{idUniversite}")
    public Universite getUniversite(@PathVariable Integer idUniversite){
        return universiteServices.getUniversite(idUniversite);
    }

}
