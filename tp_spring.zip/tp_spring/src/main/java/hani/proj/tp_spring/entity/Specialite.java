package hani.proj.tp_spring.entity;

public enum Specialite {
    IA,RESEAU,CLOUD,SECURITE
}
