package hani.proj.tp_spring.services;

import hani.proj.tp_spring.entity.Departement;
import java.util.List;

public interface IDepartementServices {

    List<Departement> getAllDepartements();

    Departement addDepartement (Departement d);

    Departement updateDepartement (Departement d);

    void deleteDepartement (Integer idDepart);

    Departement getDepartementById(Integer idDepart);

}
