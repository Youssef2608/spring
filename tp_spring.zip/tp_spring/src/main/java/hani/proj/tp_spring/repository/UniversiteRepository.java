package hani.proj.tp_spring.repository;

import hani.proj.tp_spring.entity.Universite;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UniversiteRepository extends JpaRepository<Universite,Integer> {
}
