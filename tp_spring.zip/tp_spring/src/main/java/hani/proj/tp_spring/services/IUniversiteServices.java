package hani.proj.tp_spring.services;

import hani.proj.tp_spring.entity.Universite;


import java.util.List;

public interface IUniversiteServices {

    List<Universite> getAllUniversites();

    Universite addUniversite (Universite u);

    Universite updateUniversite (Universite u);

    void deleteUniversite(Integer idUniversite);

    Universite getUniversite (Integer idUniversite);

}

