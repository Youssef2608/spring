package hani.proj.tp_spring.repository;
import hani.proj.tp_spring.entity.Etudiant;
import org.springframework.data.jpa.repository.JpaRepository;




public interface EtudiantRepository extends JpaRepository<Etudiant,Long> {
    Etudiant findEtudiantByPrenomE(String Prenom);

    Etudiant findEtudiantsByNomEAndPrenomE(String Nom,String prenom);



}
