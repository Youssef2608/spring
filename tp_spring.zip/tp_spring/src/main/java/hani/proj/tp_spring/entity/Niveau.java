package hani.proj.tp_spring.entity;

public enum Niveau {
    JUNIOR,SENIOR,EXPERT
}
