package hani.proj.tp_spring.services;

import hani.proj.tp_spring.entity.DetailEquipe;
import hani.proj.tp_spring.entity.Equipe;
import hani.proj.tp_spring.entity.Etudiant;
import hani.proj.tp_spring.repository.DetailEquipeRepository;
import hani.proj.tp_spring.repository.EquipeRepository;
import hani.proj.tp_spring.repository.EtudiantRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@AllArgsConstructor
public class EquipeServiceImp implements IEquipeServices {


    EquipeRepository equipeRepository;
    DetailEquipeRepository detailEquipeRepository;
    EtudiantRepository er;

    @Override
    public List<Equipe> getAllEquipes() {
        return equipeRepository.findAll();
    }

    @Override
    public Equipe getEquipe(Integer idEquipe) {
        return equipeRepository.findById(idEquipe).orElse(null);
    }

    @Override
    public Equipe addEquipe(Equipe e) {
        return equipeRepository.save(e);
    }

    @Override
    public Equipe updateEquipe(Equipe e) {
        return equipeRepository.save(e);
    }

    @Override
    public void deleteEquipe(Integer idEquipe) {
        equipeRepository.deleteById(idEquipe);
    }

    @Override
    public Equipe hany(Equipe e) {
        //DetailEquipe detailEquipe = e.getDetailEquipe();
      //  detailEquipe.setEquipe(e);
        equipeRepository.save(e);
Set<Etudiant> etudiants = e.getEtudiants();
for (Etudiant S:etudiants){
    Set<Equipe>myequipes = new HashSet<>();
    myequipes.add(e);
    S.setEquipes(myequipes);
    er.save(S);
}

        return e;
    }



}
