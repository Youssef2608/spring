package hani.proj.tp_spring.services;

import hani.proj.tp_spring.entity.Universite;
import hani.proj.tp_spring.repository.UniversiteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class UniversiteServiceImp implements hani.proj.tp_spring.services.IUniversiteServices {

    @Autowired
    UniversiteRepository universiteRepository;

    @Override
    public List<Universite> getAllUniversites() {
        return universiteRepository.findAll();
    }

    @Override
    public Universite addUniversite(Universite u) {
        return universiteRepository.save(u);
    }

    @Override
    public Universite updateUniversite(Universite u) {
        return universiteRepository.save(u);
    }

    @Override
    public void deleteUniversite(Integer idUniversite) {
        universiteRepository.deleteById(idUniversite);
    }

    @Override
    public Universite getUniversite(Integer idUniversite) {
        return universiteRepository.findById(idUniversite).orElse(null);
    }
}
