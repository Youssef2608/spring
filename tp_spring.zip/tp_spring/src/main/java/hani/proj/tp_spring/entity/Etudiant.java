package hani.proj.tp_spring.entity;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
public class Etudiant implements Serializable {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Integer idetudiant;
        private String prenomE;
        private String nomE;
        @Enumerated(EnumType.STRING)
        private Option option;
        @ManyToOne
        Departement departement;
        @OneToMany(mappedBy = "etudiant")
        private Set<Contrat> contrats;
        @ManyToMany(cascade = CascadeType.ALL)
        private Set<Equipe>equipes;


}
