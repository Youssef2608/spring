package hani.proj.tp_spring.controller;

import hani.proj.tp_spring.entity.Contrat;
import hani.proj.tp_spring.services.IContratServices;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/contrat")
public class ContratController {


    IContratServices contratServices;

    @GetMapping("/getAllContrat")
    public List<Contrat> getAllContrat(){
        return contratServices.getALLContrat();
    }

    @GetMapping("getContrat/{idContrat}")
    public Contrat getContrat(@PathVariable Integer idContrat){return contratServices.getContratById(idContrat);}

    @PostMapping("/addContrat")
    public Contrat addContrat(@RequestBody Contrat c){return contratServices.addContrat(c);}

    @PutMapping("/updateContrat")
    public Contrat updateContrat(@RequestBody Contrat c){return contratServices.updateContrat(c);}

    @DeleteMapping("deleteContrat/{idContrat}")
    public void deleteContrat(@PathVariable Integer idContrat){contratServices.deleteContrat(idContrat);}
}
