package hani.proj.tp_spring.controller;

import hani.proj.tp_spring.entity.Equipe;
import hani.proj.tp_spring.services.IEquipeServices;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/equipes")
public class EquipeController {


   final IEquipeServices equipeServices;

    @GetMapping("/getAllEquipes")
    public List<Equipe> getallEquipes(){return equipeServices.getAllEquipes();}

    @GetMapping("/getEquipe/{idEquipe}")
    public Equipe getEquipe(@PathVariable Integer idEquipe){return equipeServices.getEquipe(idEquipe);}

    @PostMapping("/addEquipe")
    public Equipe addEquipe(@RequestBody Equipe e){return equipeServices.addEquipe(e);}

    @PutMapping("/updateEquipe")
    public Equipe updateEquipe(@RequestBody Equipe e){return equipeServices.updateEquipe(e);}

    @DeleteMapping("/deleteEquipe/{idEquipe}")
    public void deleteEquipe(@PathVariable Integer idEquipe){equipeServices.deleteEquipe(idEquipe);}
    @PostMapping("/addEquipeAssign")
    public Equipe hany(@RequestBody Equipe e){return equipeServices.hany(e);}

   /* @GetMapping("/findEquipeByThematique/{thematique}")
    public List<Equipe> findEquipeByDetailEquipeThematiqueLike(@PathVariable ("thematique") String th){
        return equipeServices.findEquipeByDetailEquipeThematiqueLike(th);
    }

    @GetMapping("/findEquipeByEtudiant/{idEtudiant}")
    public List<Equipe> findEquipeByEtudiantIdEtudiant(@PathVariable ("idEtudiant") Long id){
        return equipeServices.findEquipeByEtudiantsIdEtudiant(id);
    }

    @GetMapping("/findEquipeByThematiqueNotNull/{idE}")
    public List<Equipe> findByEtudiantIdEtudiantAndDetailEquipeThematiqueNotNull (@PathVariable("idE") Long idEtudiant){
        return equipeServices.findByEtudiantsIdEtudiantAndDetailEquipeThematiqueNotNull(idEtudiant);
    }

    @GetMapping("/findByEtudiantAndDepart/{idE}/{idD}")
    public List<Equipe> findByEtudiantsIdEtudiantAndEtudiantsDepartementIdDepartement (@PathVariable("idE") Long idEtudiant,@PathVariable("idD") Integer idDepart){
        return equipeServices.findByEtudiantsIdEtudiantAndEtudiantsDepartementIdDepartement(idEtudiant,idDepart);
    }*/
}
